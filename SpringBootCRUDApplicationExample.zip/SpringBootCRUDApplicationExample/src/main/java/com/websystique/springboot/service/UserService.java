package com.websystique.springboot.service;


import com.websystique.springboot.model.Bi_Demodata_Setup;

import java.util.List;

public interface UserService {
	
	Bi_Demodata_Setup findById(Long bi_demodata_setup_id);

	//Bi_Demodata_Setup findByName(String name);

	void saveUser(Bi_Demodata_Setup Bi_Demodata_Setup);

	void updateUser(Bi_Demodata_Setup Bi_Demodata_Setup);

	//void deleteUserById(Long bi_demodata_setup_id);

//	void deleteAllUsers();

	List<Bi_Demodata_Setup> findAllUsers();

	boolean isUserExist(Bi_Demodata_Setup user);

	
}