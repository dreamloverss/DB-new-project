package com.websystique.springboot.repositories;

import com.websystique.springboot.model.Bi_Demodata_Setup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<Bi_Demodata_Setup, Long> {

	Bi_Demodata_Setup findByName(String name);

}
