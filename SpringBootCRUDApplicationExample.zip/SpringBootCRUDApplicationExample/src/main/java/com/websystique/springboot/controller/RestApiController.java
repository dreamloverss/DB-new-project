package com.websystique.springboot.controller;

import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.websystique.springboot.model.Bi_Demodata_Setup;
import com.websystique.springboot.service.UserService;
import com.websystique.springboot.util.CustomErrorType;

@RestController
@RequestMapping("/api")
public class RestApiController {

	public static final Logger logger = LoggerFactory.getLogger(RestApiController.class);

	@Autowired
	UserService userService; //Service which will do all data retrieval/manipulation work

	// -------------------Retrieve All Users---------------------------------------------

	@RequestMapping(value = "/user/", method = RequestMethod.GET)
	public ResponseEntity<List<Bi_Demodata_Setup>> listAllUsers() {
		List<Bi_Demodata_Setup> users = userService.findAllUsers();
		Iterator<Bi_Demodata_Setup> usersIterator = users.iterator();
		while (usersIterator.hasNext()) {
			System.out.println(usersIterator.next());
		}
		if (users.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
			// You many decide to return HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<Bi_Demodata_Setup>>(users, HttpStatus.OK);
	}

	// -------------------Retrieve Single User------------------------------------------

	@RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> getUser(@PathVariable("id") long id) {
		logger.info("Fetching User with id {}", id);
		Bi_Demodata_Setup user = userService.findById(id);
		if (user == null) {
			logger.error("User with id {} not found.", id);
			return new ResponseEntity(new CustomErrorType("User with id " + id 
					+ " not found"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Bi_Demodata_Setup>(user, HttpStatus.OK);
	}

	// -------------------Create a User-------------------------------------------

	@RequestMapping(value = "/user/", method = RequestMethod.POST)
	public ResponseEntity<?> createUser(@RequestBody Bi_Demodata_Setup user, UriComponentsBuilder ucBuilder) {
		logger.info("Creating User : {}", user);

		if (userService.isUserExist(user)) {
			logger.error("Unable to create. A User with name {} already exist", user.getName());
			return new ResponseEntity(new CustomErrorType("Unable to create. A User with name " + 
			user.getName() + " already exist."),HttpStatus.CONFLICT);
		}
		userService.saveUser(user);

		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/api/user/{id}").buildAndExpand(user.getBi_demodata_setup_id()).toUri());
		return new ResponseEntity<String>(headers, HttpStatus.CREATED);
	}

	// ------------------- Update a User ------------------------------------------------

	@RequestMapping(value = "/user/{id}", method = RequestMethod.PUT)
	public ResponseEntity<?> updateUser(@PathVariable("id") long id, @RequestBody Bi_Demodata_Setup bidemodata) {
		logger.info("Updating User with id {}", id);

		Bi_Demodata_Setup currentUser = userService.findById(id);

		if (currentUser == null) {
			logger.error("Unable to update. User with id {} not found.", id);
			return new ResponseEntity(new CustomErrorType("Unable to upate. User with id " + id + " not found."),
					HttpStatus.NOT_FOUND);
		}

		
		currentUser.setAddress_id(bidemodata.getAddress_id());
		currentUser.setName(bidemodata.getName());
		currentUser.setAdd_address1(bidemodata.getAdd_address1());
		currentUser.setAdd_city(bidemodata.getAdd_city());
		currentUser.setAdd_region_code(bidemodata.getAdd_region_code());
		currentUser.setAddr_entity_id(bidemodata.getAddr_entity_id());
		currentUser.setCompany_name(bidemodata.getCompany_name());
		currentUser.setFirst_name(bidemodata.getFirst_name());
		currentUser.setLast_name(bidemodata.getLast_name());
		currentUser.setEmail_address(bidemodata.getEmail_address());
		currentUser.setCompany_name_uc(bidemodata.getCompany_name_uc());
		currentUser.setEntity_id(bidemodata.getEntity_id());
		currentUser.setObject_type(bidemodata.getObject_type());
		currentUser.setCreation_date(bidemodata.getCreation_date());
		currentUser.setStatus_code(bidemodata.getStatus_code());
		currentUser.setAsset_id(bidemodata.getAsset_id());
		currentUser.setTitle(bidemodata.getTitle());
		currentUser.setDescription(bidemodata.getDescription());
		currentUser.setAsset_value(bidemodata.getAsset_value());
		currentUser.setActual_value(bidemodata.getActual_value());
		currentUser.setDiscount_value(bidemodata.getDiscount_value());
		currentUser.setAsset_property_id(bidemodata.getAsset_property_id());
		currentUser.setAddress1(bidemodata.getAddress1());
		currentUser.setCity(bidemodata.getCity());
		currentUser.setRegion_code(bidemodata.getRegion_code());
		currentUser.setCountry(bidemodata.getCountry());
		currentUser.setPostal_code(bidemodata.getPostal_code());
		currentUser.setAsset_valuation_id(bidemodata.getAsset_valuation_id());
		currentUser.setEst_value_for_decsion(bidemodata.getEst_value_for_decsion());
		currentUser.setValuation_date(bidemodata.getValuation_date());
		currentUser.setAdv_rate(bidemodata.getAdv_rate());
		currentUser.setRelation_id(bidemodata.getRelation_id());
		currentUser.setAmount(bidemodata.getAmount());
		currentUser.setRelation_created_date(bidemodata.getRelation_created_date());
		currentUser.setTransaction_id(bidemodata.getTransaction_id());
		currentUser.setTrn_description(bidemodata.getTrn_description());
		currentUser.setLegal_description(bidemodata.getLegal_description());
		currentUser.setExpiry_date(bidemodata.getExpiry_date());
		currentUser.setCredit_rating_code(bidemodata.getCredit_rating_code());
		currentUser.setFinance_request_id(bidemodata.getFinance_request_id());
		currentUser.setTransaction_amt(bidemodata.getTransaction_amt());
		currentUser.setCust_search_code(bidemodata.getCust_search_code());
		currentUser.setMethod_of_app(bidemodata.getMethod_of_app());
		currentUser.setFinancial_trx_id(bidemodata.getFinancial_trx_id());
		currentUser.setAsset_cost(bidemodata.getAsset_cost());
		currentUser.setTotal_net_financed(bidemodata.getTotal_net_financed());
		currentUser.setTotal_extended(bidemodata.getTotal_extended());
		currentUser.setTrx_amount(bidemodata.getTrx_amount());
		currentUser.setPurpose_code(bidemodata.getPurpose_code());
		currentUser.setNew_money(bidemodata.getNew_money());
		currentUser.setTrx_option_id(bidemodata.getTrx_option_id());
		currentUser.setPre_pmt_type_code(bidemodata.getPre_pmt_type_code());
		currentUser.setDisbursement_id(bidemodata.getDisbursement_id());
		currentUser.setGen_ledger_account(bidemodata.getGen_ledger_account());
		currentUser.setDisburse_code(bidemodata.getDisburse_code());
		currentUser.setCsys_loan_detail_id(bidemodata.getCsys_loan_detail_id());
		currentUser.setOrig_contract_date(bidemodata.getOrig_contract_date());
		currentUser.setAccount_date(bidemodata.getAccount_date());

		userService.updateUser(currentUser);
		return new ResponseEntity<Bi_Demodata_Setup>(currentUser, HttpStatus.OK);
	}

	// ------------------- Delete a User-----------------------------------------
//
//	@RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
//	public ResponseEntity<?> deleteUser(@PathVariable("id") long id) {
//		logger.info("Fetching & Deleting User with id {}", id);
//
//		User user = userService.findById(id);
//		if (user == null) {
//			logger.error("Unable to delete. User with id {} not found.", id);
//			return new ResponseEntity(new CustomErrorType("Unable to delete. User with id " + id + " not found."),
//					HttpStatus.NOT_FOUND);
//		}
//		userService.deleteUserById(id);
//		return new ResponseEntity<User>(HttpStatus.NO_CONTENT);
//	}

	// ------------------- Delete All Users-----------------------------

//	@RequestMapping(value = "/user/", method = RequestMethod.DELETE)
//	public ResponseEntity<User> deleteAllUsers() {
//		logger.info("Deleting All Users");
//
//		userService.deleteAllUsers();
//		return new ResponseEntity<User>(HttpStatus.NO_CONTENT);
//	}

}