package com.websystique.springboot.service;

import java.util.List;

import com.websystique.springboot.model.Bi_Demodata_Setup;
import com.websystique.springboot.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



@Service("userService")
@Transactional
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;

	public Bi_Demodata_Setup findById(Long id) {
		return userRepository.findOne(id);
	}

//	public Bi_Demodata_Setup findByName(String name) {
//		return userRepository.findByName(name);
//	}

	public void saveUser(Bi_Demodata_Setup Bi_Demodata_Setup) {
		userRepository.save(Bi_Demodata_Setup);
	}

	public void updateUser(Bi_Demodata_Setup Bi_Demodata_Setup){
		saveUser(Bi_Demodata_Setup);
	}

//	public void deleteUserById(Long id){
//		userRepository.delete(id);
//	}
//
//	public void deleteAllUsers(){
//		userRepository.deleteAll();
//	}

	public List<Bi_Demodata_Setup> findAllUsers(){
		return userRepository.findAll();
	}

	public boolean isUserExist(Bi_Demodata_Setup Bi_Demodata_Setup) {
		return findById(Bi_Demodata_Setup.getBi_demodata_setup_id()) != null;
	}

}
