package com.websystique.springboot.model;

import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="BI_DEMODATA_SETUP1")
public class Bi_Demodata_Setup implements Serializable{

	@Id
	@Column(name="BI_DEMODATA_SETUP_ID", nullable=true)
	private Long bi_demodata_setup_id;

	@Column(name="ADDRESS_ID", nullable=true)
	private Long address_id;
	
	@Column(name="NAME", nullable=true)
	private String name;
	
	@Column(name="ADD_ADDRESS1", nullable=true)
	private String add_address1;
	
	@Column(name="ADD_CITY", nullable=true)
	private String add_city;
	
	@Column(name="ADD_REGION_CODE", nullable=true)
	private String add_region_code;
	
	@Column(name="ADDR_ENTITY_ID", nullable=true)
	private Long addr_entity_id;
	
	@Column(name="COMPANY_NAME", nullable=true)
	private String company_name;
	
	@Column(name="FIRST_NAME", nullable=true)
	private String first_name;
	
	@Column(name="LAST_NAME", nullable=true)
	private String last_name;
	
	@Column(name="EMAIL_ADDRESS", nullable=true)
	private String email_address;
	
	@Column(name="COMPANY_NAME_UC", nullable=true)
	private String company_name_uc;
	
	@Column(name="ENTITY_ID", nullable=true)
	private Long entity_id;
	
	@Column(name="OBJECT_TYPE", nullable=true)
	private String object_type;
	
	@Column(name="CREATION_DATE", nullable=true)
	private Date creation_date;
	
	@Column(name="STATUS_CODE", nullable=true)
	private String status_code;
	
	@Column(name="ASSET_ID", nullable=true)
	private Long asset_id;
	
	@Column(name="TITLE", nullable=true)
	private String title;
	
	@Column(name="DESCRIPTION", nullable=true)
	private String description;
	
	@Column(name="ASSET_VALUE", nullable=true)
	private Long asset_value;
	
	@Column(name="ACTUAL_VALUE", nullable=true)
	private Long actual_value;
	
	@Column(name="DISCOUNT_VALUE", nullable=true)
	private Long discount_value;
	
	@Column(name="ASSET_PROPERTY_ID", nullable=true)
	private Long asset_property_id;	
	
	@Column(name="ADDRESS1", nullable=true)
	private String address1;	

	@Column(name="CITY", nullable=true)
	private String city;	

	@Column(name="REGION_CODE", nullable=true)
	private String region_code;	

	@Column(name="COUNTRY", nullable=true)
	private String country;	

	@Column(name="POSTAL_CODE", nullable=true)
	private String postal_code;	

	@Column(name="ASSET_VALUATION_ID", nullable=true)
	private Long asset_valuation_id;	
 
	@Column(name="EST_VALUE_FOR_DECSION", nullable=true)
	private Long est_value_for_decsion;	

	@Column(name="VALUATION_DATE", nullable=true)
	private Date valuation_date;	

	@Column(name="ADV_RATE", nullable=true)
	private Long adv_rate;	

	@Column(name="RELATION_ID", nullable=true)
	private Long relation_id;	

	@Column(name="AMOUNT", nullable=true)
	private Long amount;	

	@Column(name="RELATION_CREATED_DATE", nullable=true)
	private Date relation_created_date;	

	@Column(name="TRANSACTION_ID", nullable=true)
	private Long transaction_id;	

	@Column(name="TRN_DESCRIPTION", nullable=true)
	private String trn_description;	

	@Column(name="LEGAL_DESCRIPTION", nullable=true)
	private String legal_description;	

	@Column(name="EXPIRY_DATE", nullable=true)
	private Date expiry_date;	

	@Column(name="CREDIT_RATING_CODE", nullable=true)
	private String credit_rating_code;	

	@Column(name="FINANCE_REQUEST_ID", nullable=true)
	private Long finance_request_id;	

	@Column(name="TRANSACTION_AMT", nullable=true)
	private Long transaction_amt;	

	@Column(name="CUST_SEARCH_CODE", nullable=true)
	private String cust_search_code;	

	@Column(name="METHOD_OF_APP", nullable=true)
	private String method_of_app;	

	@Column(name="FINANCIAL_TRX_ID", nullable=true)
	private Long financial_trx_id;	

	@Column(name="ASSET_COST", nullable=true)
	private Long asset_cost;	

	@Column(name="TOTAL_NET_FINANCED", nullable=true)
	private Long total_net_financed;	

	@Column(name="TOTAL_EXTENDED", nullable=true)
	private Long total_extended;	

	@Column(name="TRX_AMOUNT", nullable=true)
	private Long trx_amount;	

	@Column(name="PURPOSE_CODE", nullable=true)
	private String purpose_code;	
	
	@Column(name="NEW_MONEY", nullable=true)
	private Long new_money;	
	
	@Column(name="TRX_OPTION_ID", nullable=true)
	private Long trx_option_id;	
	
	@Column(name="PRE_PMT_TYPE_CODE", nullable=true)
	private String pre_pmt_type_code;	
	
	@Column(name="DISBURSEMENT_ID", nullable=true)
	private Long disbursement_id;	
	
	@Column(name="GEN_LEDGER_ACCOUNT", nullable=true)
	private String gen_ledger_account;	
	
	@Column(name="DISBURSE_CODE", nullable=true)
	private String disburse_code;	
	
	@Column(name="CSYS_LOAN_DETAIL_ID", nullable=true)
	private Long csys_loan_detail_id;	
	
	@Column(name="ORIG_CONTRACT_DATE", nullable=true)
	private String orig_contract_date;	
	
	@Column(name="ACCOUNT_DATE", nullable=true)
	private String account_date;

	/**
	 * @return the bi_demodata_setup_id
	 */
	public Long getBi_demodata_setup_id() {
		return bi_demodata_setup_id;
	}

	/**
	 * @param bi_demodata_setup_id the bi_demodata_setup_id to set
	 */
	public void setBi_demodata_setup_id(Long bi_demodata_setup_id) {
		this.bi_demodata_setup_id = bi_demodata_setup_id;
	}

	/**
	 * @return the address_id
	 */
	public Long getAddress_id() {
		return address_id;
	}

	/**
	 * @param address_id the address_id to set
	 */
	public void setAddress_id(Long address_id) {
		this.address_id = address_id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the add_address1
	 */
	public String getAdd_address1() {
		return add_address1;
	}

	/**
	 * @param add_address1 the add_address1 to set
	 */
	public void setAdd_address1(String add_address1) {
		this.add_address1 = add_address1;
	}

	/**
	 * @return the add_city
	 */
	public String getAdd_city() {
		return add_city;
	}

	/**
	 * @param add_city the add_city to set
	 */
	public void setAdd_city(String add_city) {
		this.add_city = add_city;
	}

	/**
	 * @return the add_region_code
	 */
	public String getAdd_region_code() {
		return add_region_code;
	}

	/**
	 * @param add_region_code the add_region_code to set
	 */
	public void setAdd_region_code(String add_region_code) {
		this.add_region_code = add_region_code;
	}

	/**
	 * @return the addr_entity_id
	 */
	public Long getAddr_entity_id() {
		return addr_entity_id;
	}

	/**
	 * @param addr_entity_id the addr_entity_id to set
	 */
	public void setAddr_entity_id(Long addr_entity_id) {
		this.addr_entity_id = addr_entity_id;
	}

	/**
	 * @return the company_name
	 */
	public String getCompany_name() {
		return company_name;
	}

	/**
	 * @param company_name the company_name to set
	 */
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	/**
	 * @return the first_name
	 */
	public String getFirst_name() {
		return first_name;
	}

	/**
	 * @param first_name the first_name to set
	 */
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	/**
	 * @return the last_name
	 */
	public String getLast_name() {
		return last_name;
	}

	/**
	 * @param last_name the last_name to set
	 */
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	/**
	 * @return the email_address
	 */
	public String getEmail_address() {
		return email_address;
	}

	/**
	 * @param email_address the email_address to set
	 */
	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}

	/**
	 * @return the company_name_uc
	 */
	public String getCompany_name_uc() {
		return company_name_uc;
	}

	/**
	 * @param company_name_uc the company_name_uc to set
	 */
	public void setCompany_name_uc(String company_name_uc) {
		this.company_name_uc = company_name_uc;
	}

	/**
	 * @return the entity_id
	 */
	public Long getEntity_id() {
		return entity_id;
	}

	/**
	 * @param entity_id the entity_id to set
	 */
	public void setEntity_id(Long entity_id) {
		this.entity_id = entity_id;
	}

	/**
	 * @return the object_type
	 */
	public String getObject_type() {
		return object_type;
	}

	/**
	 * @param object_type the object_type to set
	 */
	public void setObject_type(String object_type) {
		this.object_type = object_type;
	}

	/**
	 * @return the creation_date
	 */
	public Date getCreation_date() {
		return creation_date;
	}

	/**
	 * @param creation_date the creation_date to set
	 */
	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	/**
	 * @return the status_code
	 */
	public String getStatus_code() {
		return status_code;
	}

	/**
	 * @param status_code the status_code to set
	 */
	public void setStatus_code(String status_code) {
		this.status_code = status_code;
	}

	/**
	 * @return the asset_id
	 */
	public Long getAsset_id() {
		return asset_id;
	}

	/**
	 * @param asset_id the asset_id to set
	 */
	public void setAsset_id(Long asset_id) {
		this.asset_id = asset_id;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the asset_value
	 */
	public Long getAsset_value() {
		return asset_value;
	}

	/**
	 * @param asset_value the asset_value to set
	 */
	public void setAsset_value(Long asset_value) {
		this.asset_value = asset_value;
	}

	/**
	 * @return the actual_value
	 */
	public Long getActual_value() {
		return actual_value;
	}

	/**
	 * @param actual_value the actual_value to set
	 */
	public void setActual_value(Long actual_value) {
		this.actual_value = actual_value;
	}

	/**
	 * @return the discount_value
	 */
	public Long getDiscount_value() {
		return discount_value;
	}

	/**
	 * @param discount_value the discount_value to set
	 */
	public void setDiscount_value(Long discount_value) {
		this.discount_value = discount_value;
	}

	/**
	 * @return the asset_property_id
	 */
	public Long getAsset_property_id() {
		return asset_property_id;
	}

	/**
	 * @param asset_property_id the asset_property_id to set
	 */
	public void setAsset_property_id(Long asset_property_id) {
		this.asset_property_id = asset_property_id;
	}

	/**
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}

	/**
	 * @param address1 the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the region_code
	 */
	public String getRegion_code() {
		return region_code;
	}

	/**
	 * @param region_code the region_code to set
	 */
	public void setRegion_code(String region_code) {
		this.region_code = region_code;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the postal_code
	 */
	public String getPostal_code() {
		return postal_code;
	}

	/**
	 * @param postal_code the postal_code to set
	 */
	public void setPostal_code(String postal_code) {
		this.postal_code = postal_code;
	}

	/**
	 * @return the asset_valuation_id
	 */
	public Long getAsset_valuation_id() {
		return asset_valuation_id;
	}

	/**
	 * @param asset_valuation_id the asset_valuation_id to set
	 */
	public void setAsset_valuation_id(Long asset_valuation_id) {
		this.asset_valuation_id = asset_valuation_id;
	}

	/**
	 * @return the est_value_for_decsion
	 */
	public Long getEst_value_for_decsion() {
		return est_value_for_decsion;
	}

	/**
	 * @param est_value_for_decsion the est_value_for_decsion to set
	 */
	public void setEst_value_for_decsion(Long est_value_for_decsion) {
		this.est_value_for_decsion = est_value_for_decsion;
	}

	/**
	 * @return the valuation_date
	 */
	public Date getValuation_date() {
		return valuation_date;
	}

	/**
	 * @param valuation_date the valuation_date to set
	 */
	public void setValuation_date(Date valuation_date) {
		this.valuation_date = valuation_date;
	}

	/**
	 * @return the adv_rate
	 */
	public Long getAdv_rate() {
		return adv_rate;
	}

	/**
	 * @param adv_rate the adv_rate to set
	 */
	public void setAdv_rate(Long adv_rate) {
		this.adv_rate = adv_rate;
	}

	/**
	 * @return the relation_id
	 */
	public Long getRelation_id() {
		return relation_id;
	}

	/**
	 * @param relation_id the relation_id to set
	 */
	public void setRelation_id(Long relation_id) {
		this.relation_id = relation_id;
	}

	/**
	 * @return the amount
	 */
	public Long getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(Long amount) {
		this.amount = amount;
	}

	/**
	 * @return the relation_created_date
	 */
	public Date getRelation_created_date() {
		return relation_created_date;
	}

	/**
	 * @param relation_created_date the relation_created_date to set
	 */
	public void setRelation_created_date(Date relation_created_date) {
		this.relation_created_date = relation_created_date;
	}

	/**
	 * @return the transaction_id
	 */
	public Long getTransaction_id() {
		return transaction_id;
	}

	/**
	 * @param transaction_id the transaction_id to set
	 */
	public void setTransaction_id(Long transaction_id) {
		this.transaction_id = transaction_id;
	}

	/**
	 * @return the trn_description
	 */
	public String getTrn_description() {
		return trn_description;
	}

	/**
	 * @param trn_description the trn_description to set
	 */
	public void setTrn_description(String trn_description) {
		this.trn_description = trn_description;
	}

	/**
	 * @return the legal_description
	 */
	public String getLegal_description() {
		return legal_description;
	}

	/**
	 * @param legal_description the legal_description to set
	 */
	public void setLegal_description(String legal_description) {
		this.legal_description = legal_description;
	}

	/**
	 * @return the expiry_date
	 */
	public Date getExpiry_date() {
		return expiry_date;
	}

	/**
	 * @param expiry_date the expiry_date to set
	 */
	public void setExpiry_date(Date expiry_date) {
		this.expiry_date = expiry_date;
	}

	/**
	 * @return the credit_rating_code
	 */
	public String getCredit_rating_code() {
		return credit_rating_code;
	}

	/**
	 * @param credit_rating_code the credit_rating_code to set
	 */
	public void setCredit_rating_code(String credit_rating_code) {
		this.credit_rating_code = credit_rating_code;
	}

	/**
	 * @return the finance_request_id
	 */
	public Long getFinance_request_id() {
		return finance_request_id;
	}

	/**
	 * @param finance_request_id the finance_request_id to set
	 */
	public void setFinance_request_id(Long finance_request_id) {
		this.finance_request_id = finance_request_id;
	}

	/**
	 * @return the transaction_amt
	 */
	public Long getTransaction_amt() {
		return transaction_amt;
	}

	/**
	 * @param transaction_amt the transaction_amt to set
	 */
	public void setTransaction_amt(Long transaction_amt) {
		this.transaction_amt = transaction_amt;
	}

	/**
	 * @return the cust_search_code
	 */
	public String getCust_search_code() {
		return cust_search_code;
	}

	/**
	 * @param cust_search_code the cust_search_code to set
	 */
	public void setCust_search_code(String cust_search_code) {
		this.cust_search_code = cust_search_code;
	}

	/**
	 * @return the method_of_app
	 */
	public String getMethod_of_app() {
		return method_of_app;
	}

	/**
	 * @param method_of_app the method_of_app to set
	 */
	public void setMethod_of_app(String method_of_app) {
		this.method_of_app = method_of_app;
	}

	/**
	 * @return the financial_trx_id
	 */
	public Long getFinancial_trx_id() {
		return financial_trx_id;
	}

	/**
	 * @param financial_trx_id the financial_trx_id to set
	 */
	public void setFinancial_trx_id(Long financial_trx_id) {
		this.financial_trx_id = financial_trx_id;
	}

	/**
	 * @return the asset_cost
	 */
	public Long getAsset_cost() {
		return asset_cost;
	}

	/**
	 * @param asset_cost the asset_cost to set
	 */
	public void setAsset_cost(Long asset_cost) {
		this.asset_cost = asset_cost;
	}

	/**
	 * @return the total_net_financed
	 */
	public Long getTotal_net_financed() {
		return total_net_financed;
	}

	/**
	 * @param total_net_financed the total_net_financed to set
	 */
	public void setTotal_net_financed(Long total_net_financed) {
		this.total_net_financed = total_net_financed;
	}

	/**
	 * @return the total_extended
	 */
	public Long getTotal_extended() {
		return total_extended;
	}

	/**
	 * @param total_extended the total_extended to set
	 */
	public void setTotal_extended(Long total_extended) {
		this.total_extended = total_extended;
	}

	/**
	 * @return the trx_amount
	 */
	public Long getTrx_amount() {
		return trx_amount;
	}

	/**
	 * @param trx_amount the trx_amount to set
	 */
	public void setTrx_amount(Long trx_amount) {
		this.trx_amount = trx_amount;
	}

	/**
	 * @return the purpose_code
	 */
	public String getPurpose_code() {
		return purpose_code;
	}

	/**
	 * @param purpose_code the purpose_code to set
	 */
	public void setPurpose_code(String purpose_code) {
		this.purpose_code = purpose_code;
	}

	/**
	 * @return the new_money
	 */
	public Long getNew_money() {
		return new_money;
	}

	/**
	 * @param new_money the new_money to set
	 */
	public void setNew_money(Long new_money) {
		this.new_money = new_money;
	}

	/**
	 * @return the trx_option_id
	 */
	public Long getTrx_option_id() {
		return trx_option_id;
	}

	/**
	 * @param trx_option_id the trx_option_id to set
	 */
	public void setTrx_option_id(Long trx_option_id) {
		this.trx_option_id = trx_option_id;
	}

	/**
	 * @return the pre_pmt_type_code
	 */
	public String getPre_pmt_type_code() {
		return pre_pmt_type_code;
	}

	/**
	 * @param pre_pmt_type_code the pre_pmt_type_code to set
	 */
	public void setPre_pmt_type_code(String pre_pmt_type_code) {
		this.pre_pmt_type_code = pre_pmt_type_code;
	}

	/**
	 * @return the disbursement_id
	 */
	public Long getDisbursement_id() {
		return disbursement_id;
	}

	/**
	 * @param disbursement_id the disbursement_id to set
	 */
	public void setDisbursement_id(Long disbursement_id) {
		this.disbursement_id = disbursement_id;
	}

	/**
	 * @return the gen_ledger_account
	 */
	public String getGen_ledger_account() {
		return gen_ledger_account;
	}

	/**
	 * @param gen_ledger_account the gen_ledger_account to set
	 */
	public void setGen_ledger_account(String gen_ledger_account) {
		this.gen_ledger_account = gen_ledger_account;
	}

	/**
	 * @return the disburse_code
	 */
	public String getDisburse_code() {
		return disburse_code;
	}

	/**
	 * @param disburse_code the disburse_code to set
	 */
	public void setDisburse_code(String disburse_code) {
		this.disburse_code = disburse_code;
	}

	/**
	 * @return the csys_loan_detail_id
	 */
	public Long getCsys_loan_detail_id() {
		return csys_loan_detail_id;
	}

	/**
	 * @param csys_loan_detail_id the csys_loan_detail_id to set
	 */
	public void setCsys_loan_detail_id(Long csys_loan_detail_id) {
		this.csys_loan_detail_id = csys_loan_detail_id;
	}

	/**
	 * @return the orig_contract_date
	 */
	public String getOrig_contract_date() {
		return orig_contract_date;
	}

	/**
	 * @param orig_contract_date the orig_contract_date to set
	 */
	public void setOrig_contract_date(String orig_contract_date) {
		this.orig_contract_date = orig_contract_date;
	}

	/**
	 * @return the account_date
	 */
	public String getAccount_date() {
		return account_date;
	}

	/**
	 * @param account_date the account_date to set
	 */
	public void setAccount_date(String account_date) {
		this.account_date = account_date;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((account_date == null) ? 0 : account_date.hashCode());
		result = prime * result + ((actual_value == null) ? 0 : actual_value.hashCode());
		result = prime * result + ((add_address1 == null) ? 0 : add_address1.hashCode());
		result = prime * result + ((add_city == null) ? 0 : add_city.hashCode());
		result = prime * result + ((add_region_code == null) ? 0 : add_region_code.hashCode());
		result = prime * result + ((addr_entity_id == null) ? 0 : addr_entity_id.hashCode());
		result = prime * result + ((address1 == null) ? 0 : address1.hashCode());
		result = prime * result + ((address_id == null) ? 0 : address_id.hashCode());
		result = prime * result + ((adv_rate == null) ? 0 : adv_rate.hashCode());
		result = prime * result + ((amount == null) ? 0 : amount.hashCode());
		result = prime * result + ((asset_cost == null) ? 0 : asset_cost.hashCode());
		result = prime * result + ((asset_id == null) ? 0 : asset_id.hashCode());
		result = prime * result + ((asset_property_id == null) ? 0 : asset_property_id.hashCode());
		result = prime * result + ((asset_valuation_id == null) ? 0 : asset_valuation_id.hashCode());
		result = prime * result + ((asset_value == null) ? 0 : asset_value.hashCode());
		result = prime * result + ((bi_demodata_setup_id == null) ? 0 : bi_demodata_setup_id.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((company_name == null) ? 0 : company_name.hashCode());
		result = prime * result + ((company_name_uc == null) ? 0 : company_name_uc.hashCode());
		result = prime * result + ((country == null) ? 0 : country.hashCode());
		result = prime * result + ((creation_date == null) ? 0 : creation_date.hashCode());
		result = prime * result + ((credit_rating_code == null) ? 0 : credit_rating_code.hashCode());
		result = prime * result + ((csys_loan_detail_id == null) ? 0 : csys_loan_detail_id.hashCode());
		result = prime * result + ((cust_search_code == null) ? 0 : cust_search_code.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((disburse_code == null) ? 0 : disburse_code.hashCode());
		result = prime * result + ((disbursement_id == null) ? 0 : disbursement_id.hashCode());
		result = prime * result + ((discount_value == null) ? 0 : discount_value.hashCode());
		result = prime * result + ((email_address == null) ? 0 : email_address.hashCode());
		result = prime * result + ((entity_id == null) ? 0 : entity_id.hashCode());
		result = prime * result + ((est_value_for_decsion == null) ? 0 : est_value_for_decsion.hashCode());
		result = prime * result + ((expiry_date == null) ? 0 : expiry_date.hashCode());
		result = prime * result + ((finance_request_id == null) ? 0 : finance_request_id.hashCode());
		result = prime * result + ((financial_trx_id == null) ? 0 : financial_trx_id.hashCode());
		result = prime * result + ((first_name == null) ? 0 : first_name.hashCode());
		result = prime * result + ((gen_ledger_account == null) ? 0 : gen_ledger_account.hashCode());
		result = prime * result + ((last_name == null) ? 0 : last_name.hashCode());
		result = prime * result + ((legal_description == null) ? 0 : legal_description.hashCode());
		result = prime * result + ((method_of_app == null) ? 0 : method_of_app.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((new_money == null) ? 0 : new_money.hashCode());
		result = prime * result + ((object_type == null) ? 0 : object_type.hashCode());
		result = prime * result + ((orig_contract_date == null) ? 0 : orig_contract_date.hashCode());
		result = prime * result + ((postal_code == null) ? 0 : postal_code.hashCode());
		result = prime * result + ((pre_pmt_type_code == null) ? 0 : pre_pmt_type_code.hashCode());
		result = prime * result + ((purpose_code == null) ? 0 : purpose_code.hashCode());
		result = prime * result + ((region_code == null) ? 0 : region_code.hashCode());
		result = prime * result + ((relation_created_date == null) ? 0 : relation_created_date.hashCode());
		result = prime * result + ((relation_id == null) ? 0 : relation_id.hashCode());
		result = prime * result + ((status_code == null) ? 0 : status_code.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + ((total_extended == null) ? 0 : total_extended.hashCode());
		result = prime * result + ((total_net_financed == null) ? 0 : total_net_financed.hashCode());
		result = prime * result + ((transaction_amt == null) ? 0 : transaction_amt.hashCode());
		result = prime * result + ((transaction_id == null) ? 0 : transaction_id.hashCode());
		result = prime * result + ((trn_description == null) ? 0 : trn_description.hashCode());
		result = prime * result + ((trx_amount == null) ? 0 : trx_amount.hashCode());
		result = prime * result + ((trx_option_id == null) ? 0 : trx_option_id.hashCode());
		result = prime * result + ((valuation_date == null) ? 0 : valuation_date.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bi_Demodata_Setup other = (Bi_Demodata_Setup) obj;
		if (account_date == null) {
			if (other.account_date != null)
				return false;
		} else if (!account_date.equals(other.account_date))
			return false;
		if (actual_value == null) {
			if (other.actual_value != null)
				return false;
		} else if (!actual_value.equals(other.actual_value))
			return false;
		if (add_address1 == null) {
			if (other.add_address1 != null)
				return false;
		} else if (!add_address1.equals(other.add_address1))
			return false;
		if (add_city == null) {
			if (other.add_city != null)
				return false;
		} else if (!add_city.equals(other.add_city))
			return false;
		if (add_region_code == null) {
			if (other.add_region_code != null)
				return false;
		} else if (!add_region_code.equals(other.add_region_code))
			return false;
		if (addr_entity_id == null) {
			if (other.addr_entity_id != null)
				return false;
		} else if (!addr_entity_id.equals(other.addr_entity_id))
			return false;
		if (address1 == null) {
			if (other.address1 != null)
				return false;
		} else if (!address1.equals(other.address1))
			return false;
		if (address_id == null) {
			if (other.address_id != null)
				return false;
		} else if (!address_id.equals(other.address_id))
			return false;
		if (adv_rate == null) {
			if (other.adv_rate != null)
				return false;
		} else if (!adv_rate.equals(other.adv_rate))
			return false;
		if (amount == null) {
			if (other.amount != null)
				return false;
		} else if (!amount.equals(other.amount))
			return false;
		if (asset_cost == null) {
			if (other.asset_cost != null)
				return false;
		} else if (!asset_cost.equals(other.asset_cost))
			return false;
		if (asset_id == null) {
			if (other.asset_id != null)
				return false;
		} else if (!asset_id.equals(other.asset_id))
			return false;
		if (asset_property_id == null) {
			if (other.asset_property_id != null)
				return false;
		} else if (!asset_property_id.equals(other.asset_property_id))
			return false;
		if (asset_valuation_id == null) {
			if (other.asset_valuation_id != null)
				return false;
		} else if (!asset_valuation_id.equals(other.asset_valuation_id))
			return false;
		if (asset_value == null) {
			if (other.asset_value != null)
				return false;
		} else if (!asset_value.equals(other.asset_value))
			return false;
		if (bi_demodata_setup_id == null) {
			if (other.bi_demodata_setup_id != null)
				return false;
		} else if (!bi_demodata_setup_id.equals(other.bi_demodata_setup_id))
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (company_name == null) {
			if (other.company_name != null)
				return false;
		} else if (!company_name.equals(other.company_name))
			return false;
		if (company_name_uc == null) {
			if (other.company_name_uc != null)
				return false;
		} else if (!company_name_uc.equals(other.company_name_uc))
			return false;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		if (creation_date == null) {
			if (other.creation_date != null)
				return false;
		} else if (!creation_date.equals(other.creation_date))
			return false;
		if (credit_rating_code == null) {
			if (other.credit_rating_code != null)
				return false;
		} else if (!credit_rating_code.equals(other.credit_rating_code))
			return false;
		if (csys_loan_detail_id == null) {
			if (other.csys_loan_detail_id != null)
				return false;
		} else if (!csys_loan_detail_id.equals(other.csys_loan_detail_id))
			return false;
		if (cust_search_code == null) {
			if (other.cust_search_code != null)
				return false;
		} else if (!cust_search_code.equals(other.cust_search_code))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (disburse_code == null) {
			if (other.disburse_code != null)
				return false;
		} else if (!disburse_code.equals(other.disburse_code))
			return false;
		if (disbursement_id == null) {
			if (other.disbursement_id != null)
				return false;
		} else if (!disbursement_id.equals(other.disbursement_id))
			return false;
		if (discount_value == null) {
			if (other.discount_value != null)
				return false;
		} else if (!discount_value.equals(other.discount_value))
			return false;
		if (email_address == null) {
			if (other.email_address != null)
				return false;
		} else if (!email_address.equals(other.email_address))
			return false;
		if (entity_id == null) {
			if (other.entity_id != null)
				return false;
		} else if (!entity_id.equals(other.entity_id))
			return false;
		if (est_value_for_decsion == null) {
			if (other.est_value_for_decsion != null)
				return false;
		} else if (!est_value_for_decsion.equals(other.est_value_for_decsion))
			return false;
		if (expiry_date == null) {
			if (other.expiry_date != null)
				return false;
		} else if (!expiry_date.equals(other.expiry_date))
			return false;
		if (finance_request_id == null) {
			if (other.finance_request_id != null)
				return false;
		} else if (!finance_request_id.equals(other.finance_request_id))
			return false;
		if (financial_trx_id == null) {
			if (other.financial_trx_id != null)
				return false;
		} else if (!financial_trx_id.equals(other.financial_trx_id))
			return false;
		if (first_name == null) {
			if (other.first_name != null)
				return false;
		} else if (!first_name.equals(other.first_name))
			return false;
		if (gen_ledger_account == null) {
			if (other.gen_ledger_account != null)
				return false;
		} else if (!gen_ledger_account.equals(other.gen_ledger_account))
			return false;
		if (last_name == null) {
			if (other.last_name != null)
				return false;
		} else if (!last_name.equals(other.last_name))
			return false;
		if (legal_description == null) {
			if (other.legal_description != null)
				return false;
		} else if (!legal_description.equals(other.legal_description))
			return false;
		if (method_of_app == null) {
			if (other.method_of_app != null)
				return false;
		} else if (!method_of_app.equals(other.method_of_app))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (new_money == null) {
			if (other.new_money != null)
				return false;
		} else if (!new_money.equals(other.new_money))
			return false;
		if (object_type == null) {
			if (other.object_type != null)
				return false;
		} else if (!object_type.equals(other.object_type))
			return false;
		if (orig_contract_date == null) {
			if (other.orig_contract_date != null)
				return false;
		} else if (!orig_contract_date.equals(other.orig_contract_date))
			return false;
		if (postal_code == null) {
			if (other.postal_code != null)
				return false;
		} else if (!postal_code.equals(other.postal_code))
			return false;
		if (pre_pmt_type_code == null) {
			if (other.pre_pmt_type_code != null)
				return false;
		} else if (!pre_pmt_type_code.equals(other.pre_pmt_type_code))
			return false;
		if (purpose_code == null) {
			if (other.purpose_code != null)
				return false;
		} else if (!purpose_code.equals(other.purpose_code))
			return false;
		if (region_code == null) {
			if (other.region_code != null)
				return false;
		} else if (!region_code.equals(other.region_code))
			return false;
		if (relation_created_date == null) {
			if (other.relation_created_date != null)
				return false;
		} else if (!relation_created_date.equals(other.relation_created_date))
			return false;
		if (relation_id == null) {
			if (other.relation_id != null)
				return false;
		} else if (!relation_id.equals(other.relation_id))
			return false;
		if (status_code == null) {
			if (other.status_code != null)
				return false;
		} else if (!status_code.equals(other.status_code))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (total_extended == null) {
			if (other.total_extended != null)
				return false;
		} else if (!total_extended.equals(other.total_extended))
			return false;
		if (total_net_financed == null) {
			if (other.total_net_financed != null)
				return false;
		} else if (!total_net_financed.equals(other.total_net_financed))
			return false;
		if (transaction_amt == null) {
			if (other.transaction_amt != null)
				return false;
		} else if (!transaction_amt.equals(other.transaction_amt))
			return false;
		if (transaction_id == null) {
			if (other.transaction_id != null)
				return false;
		} else if (!transaction_id.equals(other.transaction_id))
			return false;
		if (trn_description == null) {
			if (other.trn_description != null)
				return false;
		} else if (!trn_description.equals(other.trn_description))
			return false;
		if (trx_amount == null) {
			if (other.trx_amount != null)
				return false;
		} else if (!trx_amount.equals(other.trx_amount))
			return false;
		if (trx_option_id == null) {
			if (other.trx_option_id != null)
				return false;
		} else if (!trx_option_id.equals(other.trx_option_id))
			return false;
		if (valuation_date == null) {
			if (other.valuation_date != null)
				return false;
		} else if (!valuation_date.equals(other.valuation_date))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Bi_Demodata_Setup [bi_demodata_setup_id=" + bi_demodata_setup_id + ", address_id=" + address_id
				+ ", name=" + name + ", add_address1=" + add_address1 + ", add_city=" + add_city + ", add_region_code="
				+ add_region_code + ", addr_entity_id=" + addr_entity_id + ", company_name=" + company_name
				+ ", first_name=" + first_name + ", last_name=" + last_name + ", email_address=" + email_address
				+ ", company_name_uc=" + company_name_uc + ", entity_id=" + entity_id + ", object_type=" + object_type
				+ ", creation_date=" + creation_date + ", status_code=" + status_code + ", asset_id=" + asset_id
				+ ", title=" + title + ", description=" + description + ", asset_value=" + asset_value
				+ ", actual_value=" + actual_value + ", discount_value=" + discount_value + ", asset_property_id="
				+ asset_property_id + ", address1=" + address1 + ", city=" + city + ", region_code=" + region_code
				+ ", country=" + country + ", postal_code=" + postal_code + ", asset_valuation_id=" + asset_valuation_id
				+ ", est_value_for_decsion=" + est_value_for_decsion + ", valuation_date=" + valuation_date
				+ ", adv_rate=" + adv_rate + ", relation_id=" + relation_id + ", amount=" + amount
				+ ", relation_created_date=" + relation_created_date + ", transaction_id=" + transaction_id
				+ ", trn_description=" + trn_description + ", legal_description=" + legal_description + ", expiry_date="
				+ expiry_date + ", credit_rating_code=" + credit_rating_code + ", finance_request_id="
				+ finance_request_id + ", transaction_amt=" + transaction_amt + ", cust_search_code=" + cust_search_code
				+ ", method_of_app=" + method_of_app + ", financial_trx_id=" + financial_trx_id + ", asset_cost="
				+ asset_cost + ", total_net_financed=" + total_net_financed + ", total_extended=" + total_extended
				+ ", trx_amount=" + trx_amount + ", purpose_code=" + purpose_code + ", new_money=" + new_money
				+ ", trx_option_id=" + trx_option_id + ", pre_pmt_type_code=" + pre_pmt_type_code + ", disbursement_id="
				+ disbursement_id + ", gen_ledger_account=" + gen_ledger_account + ", disburse_code=" + disburse_code
				+ ", csys_loan_detail_id=" + csys_loan_detail_id + ", orig_contract_date=" + orig_contract_date
				+ ", account_date=" + account_date + "]";
	}


	
	


}
